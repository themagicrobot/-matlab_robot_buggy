addpath('/home/pi/lib')

power=100
rotate=false
motors_adv(0,0)



