clear all
my_buggy=buggy()
my_buggy=my_buggy.setup_enviroment()
my_buggy=my_buggy.motors(100,100,1)
