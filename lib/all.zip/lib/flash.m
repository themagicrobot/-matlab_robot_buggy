function [] = flash() ;

	pin_out("0000",0.1)
	pin_out("1111",0.1)
	pin_out("0000",0.1)
	pin_out("1111",0.1)
	pin_out("0000",0.1)
	pin_out("1111",0.1)
	pin_out("0000",0.1)
	pin_out("1111",0.1)
	pin_out("0000",0.1)
end
